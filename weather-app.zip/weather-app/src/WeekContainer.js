import React from 'react'
import DayCard from './DayCard'
import './WeekContainer.css';

 class Weekcontainer extends React.Component {
    state = {
        fullData: [],
        dailyData: [],
        location:"Jamshedpur, IN",
        n:5
      }
      onSubmit(e){
          e.preventDefault();
          this.state.location = this.location.value;
          this.state.n = this.n.value;
          console.log(this.state.location);
          console.log(this.state.n);
          this.componentDidMount();
      }
      componentDidMount = () => {
        const weatherURL =
        `http://api.openweathermap.org/data/2.5/forecast?q=${this.state.location}&units=metric&APPID=add5b02e09a099624b9ab722164fb37b`
        fetch(weatherURL)
        .then(res => res.json())
        .then(data => {
        const dailyData = data.list.filter(reading => reading.dt_txt.includes("18:00:00"))
        this.setState({
        fullData: data.list,
        dailyData: dailyData
      }, 
      () => console.log(this.state))
     
    })
  }

  formatDayCards = () => {
    return this.state.dailyData.slice(0,this.state.n).map((reading, index) => <DayCard reading={reading} key={index} />)
  }
       render(){
         return (
          <div className ="container">
             <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                <ul class="navbar-nav">
                <li class="nav-item active ">
                  <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
              </ul>
              <form className="form">
                     <input type="text" placeholder="Location" ref={(c) => (this.location=c)}/>
                     <input type="text" placeholder="Number" ref={(d) => (this.n=d)}/>
                      <button onClick={this.onSubmit.bind(this)} className="btn btn-primary ml-2">check</button>
              </form>
            </nav>
              <div class="jumbotron">
                <h1>Welcome.... <br/>Lets Check today's weather </h1>
                </div>
                <hr/>
                <div className="row justify-content-center">
                    {this.formatDayCards()}
                </div>
                <hr/>
            </div>
        )
    }
}
export default Weekcontainer;